package org.boa.usvisaprocess;

import static org.camunda.bpm.engine.variable.Variables.putValue;

import java.util.Calendar;
import java.util.logging.Logger;

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.query.PeriodUnit;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.spring.boot.starter.annotation.EnableProcessApplication;
import org.camunda.bpm.spring.boot.starter.event.ProcessApplicationStartedEvent;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.event.EventListener;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableProcessApplication("usvisaprocess")
//@Slf4j
public class CamundaApplication{
	
	 private final Logger logger=Logger.getLogger(CamundaApplication.class.getName());
	@Autowired
	private RuntimeService runTimeService;
	//@Autowired
	//private HistoryService historyService;
	private static final String PROCESS_DEFINITION_KEY = "generateRandom";	
	  public static void main(String... args) {
	    SpringApplication.run(CamundaApplication.class, args);
	  }
	@EventListener  
    public void onStart(final ProcessApplicationStartedEvent event)
    {
		
		ProcessEngine processEngine=ProcessEngines.getDefaultProcessEngine();		
		//ProcessInstance processInstance=runTimeService.startProcessInstanceByKey(PROCESS_DEFINITION_KEY,
	    //	      putValue("email","parameswari@gmail.com"));
		HistoryService historyService = processEngine.getHistoryService();
        System.out.println("Querying Job Count"+historyService.createHistoricJobLogQuery().count());
        Calendar calendar = Calendar.getInstance();
        historyService.createHistoricProcessInstanceReport()
          .startedBefore(calendar.getTime())
          .duration(PeriodUnit.MONTH);
        logger.info("Version="+processEngine.VERSION);
		
    	
    }

}
