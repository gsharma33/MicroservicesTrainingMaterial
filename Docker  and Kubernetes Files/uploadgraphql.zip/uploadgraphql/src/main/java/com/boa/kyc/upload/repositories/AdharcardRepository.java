package com.boa.kyc.upload.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.kyc.upload.models.AdharCard;

public interface AdharcardRepository extends JpaRepository<AdharCard,String>{

}
