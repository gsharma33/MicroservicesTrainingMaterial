package com.virtusa.jwtsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
