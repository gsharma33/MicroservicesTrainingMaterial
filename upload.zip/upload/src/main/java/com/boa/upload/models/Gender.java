package com.boa.upload.models;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}